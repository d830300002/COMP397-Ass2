module config {
    export enum Scene {
        START,
        PLAY,
        INS,
        END
    }
}