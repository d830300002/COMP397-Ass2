module config {
    export class Screen {
        public static WIDTH:number = 900;
        public static HEIGHT:number = 450;
        public static HALF_WIDTH:number = 450;
        public static HALF_HEIGHT:number = 225;
    }
}