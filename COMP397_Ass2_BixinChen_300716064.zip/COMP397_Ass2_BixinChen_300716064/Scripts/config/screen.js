var config;
(function (config) {
    var Screen = /** @class */ (function () {
        function Screen() {
        }
        Screen.WIDTH = 900;
        Screen.HEIGHT = 450;
        Screen.HALF_WIDTH = 450;
        Screen.HALF_HEIGHT = 225;
        return Screen;
    }());
    config.Screen = Screen;
})(config || (config = {}));
//# sourceMappingURL=screen.js.map